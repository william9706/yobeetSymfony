<?php

/**
 * Setting filter form.
 *
 * @package    symfony12
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: SettingFormFilter.class.php 28974 2010-04-04 22:59:54Z Kris.Wallsmith $
 */
class SettingFormFilter extends PluginSettingFormFilter
{
  public function configure()
  {
  }
}
