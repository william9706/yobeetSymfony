<?php

/**
 * ArticleTranslation form.
 *
 * @package    form
 * @subpackage ArticleTranslation
 * @version    SVN: $Id: ArticleTranslationForm.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ArticleTranslationForm extends BaseArticleTranslationForm
{
  public function configure()
  {
  }
}